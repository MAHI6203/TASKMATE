from django.apps import AppConfig


class TodolistAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'todolist_app'
